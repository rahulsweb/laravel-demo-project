<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Order;
use Illuminate\Http\Request;
use Validator;

class OrderController extends Controller
{
    //

    public function orderTrack(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'order_code' => 'required',
        ],
            [
                'email.required' => 'Email Required',
                'order_code.required' => 'Order Code Required',

            ]

        );

        if ($validator->fails()) {
            return response()->json([

                'status' => false,
                'message' => $validator->errors(),

                'data' => [],
            ], 401);
        }
        $orders = Order::where('order_code', $request->order_code)->with('users', 'orderPayment', 'order_carts')->get();

        if (isset($orders->first()->users->email)) {
            $email = $orders->first()->users->email;
        
        } else {

            return response()->json([

                'status' => false,
                'message' => 'Your Order Code Or Email Is invalid',

                'data' => [],
            ], 401);

        }
        
        if ($email == $request->email && isset($orders)) {

      
        return response()->json([

            'status' => true,
            'message' => 'Success',

            'data' => $orders,
        ], 401);
        }

       
    }

    public function orderTrackProcess(Request $request)
    {
   

    }

}
