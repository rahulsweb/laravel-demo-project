<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Auth;
class ProfileController extends Controller
{
    //
    public function getProfileDetails(Request $request)
    {
       
        $user =User::find(Auth::user()->id);

        if (!$user) {
            return response()->json([

                'status' => false,
                'message' => 'User Not Found',

                'data' => [],
            ], 401);

        }

        return response()->json([

            'status' => true,
            'message' => 'success',

            'data' => $user,
        ], 401);
    }




    public function update(Request $request)
    {

        $user = User::find(Auth::user()->id);

        if ($request->hasFile('profile')) {

            $filename = "";
            $file = $request->file('profile');
            $location = 'User/';

            $filename = time() . "_" . $file->getClientOriginalName();

            $user->profile = $location . $filename;

            $result = $file->move($location, $filename);

        }

        $data = [
            'first_name' => $request->firstname,
            'last_name' => $request->lastname,
            'profile' => $location.$filename,

        ];
          if(!$user->update($data))
            {
                return response()->json([

                    'status' => false,
                    'message' => 'Profile Is Not Updated',
        
                    'data' => $user,
                ], 401);

            }


            return response()->json([

                'status' => true,
                'message' => 'success',
    
                'data' => $user,
            ], 401);
          
  
        
    }









}
