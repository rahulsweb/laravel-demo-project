<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\WishList;
use Auth;
use App\Product;
use Symfony\Component\HttpFoundation\Request;

class WishListController extends Controller
{
    //

    public function index()
    {
        $products = WishList::with('products')
            ->where('user_id', Auth::user()->id)
            ->get();
            if(!$products->first())
            {
                return response()->json([
                    'status' => false,
                    'message' => 'Product Not Found',
        
                    'data' => [
        
                        'wishlist' => [],
        
                    ],
        
                ]);
            }

            return response()->json([
                'status' => true,
                'message' => 'Success',
    
                'data' => [
    
                    'wishlist' => [$products],
    
                ],
    
            ]);
        

    }







    public function store(Request $request)
    {

        $product=Product::find($request->wish);
        if(!$product)
        {
            return response()->json([

                'status' => false,
                'message' => 'Product Not Found',
    
                'data' => [],
            ], 401);
        }


        
        $wishlist = new WishList;
        if (auth()->user()->id) {
            $wishlistData = $wishlist->where('product_id', '=', $request->wish)->where('user_id', '=', auth()->user()->id)->pluck('id');

            if (!$wishlistData->first()) {

                $data = [
                    'user_id' => auth()->user()->id,
                    'product_id' => $request->wish,

                ];

                $wishlist=$wishlist->create($data);
                return response()->json([

                    'status' => true,
                    'message' => 'WishList Add SuccessFully',
        
                    'data' => [],
                    
                ], 401);

            }
            else
            {
                return response()->json([

                    'status' => false,
                    'message' => 'Product Already Added',
        
                    'data' => [],
                ], 401);
            }

            
        }
        return response()->json([

            'status' => false,
            'message' => 'Please Login Your Account',

            'data' => [],
        ], 401);
    }






    public function deleteWishlist(Request $request)
    {

        $wishlist = WishList::where('product_id', $request->id)->where('user_id', Auth::user()->id);

        if (!$wishlist->first()) {
            return response()->json([
                'status' => false,
                'message' => 'Wishlist Not Found',

                'data' => [

                ],

            ]);
        }
        $wishlist->delete();
        return response()->json([
            'status' => true,
            'message' => 'Delete Successfully',

            'data' => [

            ],

        ]);

    }

}
