<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    //

    public function getProductList(Request $request)
    {
        $products = Product::GetAll();

        if (!$products) {
            return response()->json([

                'status' => false,
                'message' => 'Product Not Found',

                'data' => $products,
            ], 401);

        }

        return response()->json([

            'status' => true,
            'message' => 'success',

            'data' => $products,
        ], 401);

    }

    public function getProductDetails(Request $request)
    {

        $products = Product::with('categories', 'product_image', 'order_carts', 'users', 'product_attribute')->find($request->id);

        if (!$products) {
            return response()->json([

                'status' => false,
                'message' => 'Product Not Found',

                'data' => [],
            ], 401);

        }

        return response()->json([

            'status' => true,
            'message' => 'success',

            'data' => $products,
        ], 401);

    }

}
